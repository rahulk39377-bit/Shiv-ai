# ॐ SHIV AI — Smart Chat PWA

**Hindi + English + Hinglish** supporting Smart AI Chat with Voice Input/Reply, Business Mode (LADLA GROUP), Developer Mode, Creative Mode, File Assistant, Dashboard & Settings.

## Features

| Feature | Description |
|---------|-------------|
| 💬 Smart Chat | Natural conversation in Hindi / English / Hinglish |
| 🎤 Voice Input | Bolkar command do (Web Speech API) |
| 🔊 Voice Reply | SHIV AI awaaz mein jawab |
| 💼 Business Mode | LADLA RENT ideas, pricing, marketing |
| 🛠️ Developer Mode | HTML / CSS / JS code generate & explain |
| 🎨 Creative Mode | Poster, reel, tagline concepts |
| 📂 File Assistant | Text files upload & summary (demo) |
| 📊 Dashboard | Chats, messages, voice usage stats |
| 🔐 Settings | Voice, language, privacy controls |
| 📱 PWA | Phone pe install kar sakte ho |

## Quick Start

1. Folder open karo: `shiv-ai/`
2. Local server se chalao (recommended):
   ```bash
   npx serve .
   # ya
   python3 -m http.server 8080
   ```
3. Browser mein `http://localhost:8080` (ya jo port ho) kholo.
4. Chrome / Edge recommended (Voice ke liye).

## Phone pe Install (PWA)

- Chrome → Menu → **Install app** / **Add to Home screen**
- iOS Safari → Share → **Add to Home Screen**

## Notes

- Yeh **frontend demo** hai. AI replies local smart rules se aate hain (real LLM API nahi).
- Saara data browser ke **localStorage** mein rehta hai.
- Voice features HTTPS ya localhost pe best kaam karte hain.

## Folder Structure

```
shiv-ai/
├── index.html
├── css/style.css
├── js/app.js
├── sw.js
├── manifest.json
├── icons/
│   ├── icon.svg
│   ├── icon-192.png
│   └── icon-512.png
└── README.md
```

---
Made with ॐ for LADLA GROUP style workflows.
