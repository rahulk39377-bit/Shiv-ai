/* ========== SHIV AI — Core App Logic ========== */

const SHIV = {
  // State
  voiceReply: true,
  lang: 'hinglish',
  autoListen: false,
  saveHistory: true,
  isListening: false,
  recognition: null,
  synth: window.speechSynthesis,
  chatCount: 0,
  msgCount: 0,
  voiceCount: 0,
  currentMode: 'chat',

  // DOM refs
  $: (sel) => document.querySelector(sel),
  $$: (sel) => document.querySelectorAll(sel),

  init() {
    this.loadSettings();
    this.bindEvents();
    this.initSpeech();
    this.updateStats();
    this.hideSplash();
  },

  hideSplash() {
    setTimeout(() => {
      this.$('#splash').classList.add('hide');
      this.$('#app').classList.remove('hidden');
    }, 1400);
  },

  loadSettings() {
    try {
      const s = JSON.parse(localStorage.getItem('shiv_settings') || '{}');
      this.voiceReply = s.voiceReply !== false;
      this.lang = s.lang || 'hinglish';
      this.autoListen = !!s.autoListen;
      this.saveHistory = s.saveHistory !== false;
      this.chatCount = s.chatCount || 0;
      this.msgCount = s.msgCount || 0;
      this.voiceCount = s.voiceCount || 0;

      this.$('#setting-voice').checked = this.voiceReply;
      this.$('#setting-lang').value = this.lang;
      this.$('#setting-auto-listen').checked = this.autoListen;
      this.$('#setting-save').checked = this.saveHistory;
      this.$('#voice-toggle').classList.toggle('active', this.voiceReply);
    } catch (e) {}
  },

  saveSettings() {
    if (!this.saveHistory) return;
    localStorage.setItem('shiv_settings', JSON.stringify({
      voiceReply: this.voiceReply,
      lang: this.lang,
      autoListen: this.autoListen,
      saveHistory: this.saveHistory,
      chatCount: this.chatCount,
      msgCount: this.msgCount,
      voiceCount: this.voiceCount
    }));
  },

  bindEvents() {
    // Sidebar
    this.$('#menu-btn')?.addEventListener('click', () => this.toggleSidebar(true));
    this.$('#close-sidebar')?.addEventListener('click', () => this.toggleSidebar(false));
    this.$('#overlay')?.addEventListener('click', () => this.toggleSidebar(false));

    // Nav items
    this.$$('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        this.switchView(btn.dataset.view);
        this.toggleSidebar(false);
      });
    });

    // Tool cards & back buttons
    this.$$('[data-view]').forEach(el => {
      if (!el.classList.contains('nav-item')) {
        el.addEventListener('click', () => this.switchView(el.dataset.view));
      }
    });

    // Chat send
    this.$('#send-btn').addEventListener('click', () => this.sendMessage());
    this.$('#user-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.sendMessage();
      }
    });

    // Auto-resize textarea
    this.$('#user-input').addEventListener('input', function () {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });

    // Mic
    this.$('#mic-btn').addEventListener('click', () => this.toggleMic());

    // Voice toggle
    this.$('#voice-toggle').addEventListener('click', () => {
      this.voiceReply = !this.voiceReply;
      this.$('#voice-toggle').classList.toggle('active', this.voiceReply);
      this.$('#setting-voice').checked = this.voiceReply;
      this.saveSettings();
    });

    // New chat
    this.$('#new-chat').addEventListener('click', () => this.newChat());

    // Quick actions
    this.$$('.qa-btn, .mode-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const prompt = btn.dataset.prompt;
        if (prompt) {
          this.switchView('chat');
          this.$('#user-input').value = prompt;
          this.sendMessage();
        }
      });
    });

    // Settings
    this.$('#setting-voice').addEventListener('change', (e) => {
      this.voiceReply = e.target.checked;
      this.$('#voice-toggle').classList.toggle('active', this.voiceReply);
      this.saveSettings();
    });
    this.$('#setting-lang').addEventListener('change', (e) => {
      this.lang = e.target.value;
      this.saveSettings();
    });
    this.$('#setting-auto-listen').addEventListener('change', (e) => {
      this.autoListen = e.target.checked;
      this.saveSettings();
    });
    this.$('#setting-save').addEventListener('change', (e) => {
      this.saveHistory = e.target.checked;
      this.saveSettings();
    });
    this.$('#clear-data').addEventListener('click', () => {
      if (confirm('Saari local data clear ho jaayegi. Confirm?')) {
        localStorage.removeItem('shiv_settings');
        location.reload();
      }
    });

    // File upload
    const uploadBox = this.$('#upload-box');
    const fileInput = this.$('#file-input');
    uploadBox?.addEventListener('click', () => fileInput.click());
    uploadBox?.addEventListener('dragover', (e) => {
      e.preventDefault();
      uploadBox.classList.add('dragover');
    });
    uploadBox?.addEventListener('dragleave', () => uploadBox.classList.remove('dragover'));
    uploadBox?.addEventListener('drop', (e) => {
      e.preventDefault();
      uploadBox.classList.remove('dragover');
      if (e.dataTransfer.files[0]) this.handleFile(e.dataTransfer.files[0]);
    });
    fileInput?.addEventListener('change', (e) => {
      if (e.target.files[0]) this.handleFile(e.target.files[0]);
    });
  },

  toggleSidebar(open) {
    const sidebar = this.$('#sidebar');
    const overlay = this.$('#overlay');
    if (open) {
      sidebar.classList.add('open');
      overlay.classList.add('show');
    } else {
      sidebar.classList.remove('open');
      overlay.classList.remove('show');
    }
  },

  switchView(view) {
    this.$$('.view').forEach(v => v.classList.remove('active'));
    this.$$('.nav-item').forEach(n => n.classList.remove('active'));

    const target = this.$(`#view-${view}`);
    if (target) target.classList.add('active');

    const nav = this.$(`.nav-item[data-view="${view}"]`);
    if (nav) nav.classList.add('active');

    const titles = {
      chat: '💬 Smart Chat',
      dashboard: '📊 Dashboard',
      business: '💼 Business Mode',
      developer: '🛠️ Developer Mode',
      creative: '🎨 Creative Mode',
      files: '📂 File Assistant',
      settings: '🔐 Settings'
    };
    this.$('#current-mode').textContent = titles[view] || 'SHIV AI';
    this.currentMode = view;

    if (view === 'dashboard') this.updateStats();
  },

  // ========== Speech ==========
  initSpeech() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn('Speech Recognition not supported');
      return;
    }
    this.recognition = new SpeechRecognition();
    this.recognition.continuous = false;
    this.recognition.interimResults = false;
    this.recognition.lang = this.lang === 'english' ? 'en-IN' : 'hi-IN';

    this.recognition.onresult = (e) => {
      const text = e.results[0][0].transcript;
      this.$('#user-input').value = text;
      this.stopMic();
      this.sendMessage();
    };

    this.recognition.onerror = () => this.stopMic();
    this.recognition.onend = () => this.stopMic();
  },

  toggleMic() {
    if (!this.recognition) {
      this.addMessage('ai', '⚠️ Is browser mein Voice Input support nahi hai. Chrome / Edge try karo.');
      return;
    }
    if (this.isListening) {
      this.stopMic();
    } else {
      this.startMic();
    }
  },

  startMic() {
    this.isListening = true;
    this.$('#mic-btn').classList.add('listening');
    this.recognition.lang = this.lang === 'english' ? 'en-IN' : 'hi-IN';
    try {
      this.recognition.start();
      this.voiceCount++;
      this.saveSettings();
    } catch (e) {
      this.stopMic();
    }
  },

  stopMic() {
    this.isListening = false;
    this.$('#mic-btn').classList.remove('listening');
    try { this.recognition?.stop(); } catch (e) {}
  },

  speak(text) {
    if (!this.voiceReply || !this.synth) return;
    this.synth.cancel();
    // Clean text for speech
    const clean = text
      .replace(/[*_#`~]/g, '')
      .replace(/\n+/g, '. ')
      .replace(/🙏|💬|💼|🛠️|🎨|📂|🔐|📊|🏠|💡|📢|💰|📈|🎯|📍|📱|⚡|✅|🌙|🌐|📖|🎬|✨|🪔|🔊|🎤|➤|☰|✕|＋/g, '');

    const utter = new SpeechSynthesisUtterance(clean);
    utter.lang = this.lang === 'english' ? 'en-IN' : 'hi-IN';
    utter.rate = 1.05;
    utter.pitch = 1;

    // Prefer Indian voice if available
    const voices = this.synth.getVoices();
    const preferred = voices.find(v =>
      (this.lang === 'english' ? v.lang.startsWith('en') : v.lang.startsWith('hi')) &&
      (v.name.includes('India') || v.name.includes('Indian') || v.name.includes('Google'))
    ) || voices.find(v => v.lang.startsWith(this.lang === 'english' ? 'en' : 'hi'));
    if (preferred) utter.voice = preferred;

    this.synth.speak(utter);
  },

  // ========== Chat ==========
  newChat() {
    const container = this.$('#chat-messages');
    container.innerHTML = '';
    this.addMessage('ai', '🙏 Naya chat shuru! Main SHIV AI hoon. Kya madad chahiye?');
    this.chatCount++;
    this.saveSettings();
    this.updateStats();
  },

  sendMessage() {
    const input = this.$('#user-input');
    const text = input.value.trim();
    if (!text) return;

    this.addMessage('user', text);
    input.value = '';
    input.style.height = 'auto';
    this.msgCount++;
    this.saveSettings();

    // Show typing
    this.showTyping();

    // Simulate AI response (local smart replies)
    setTimeout(() => {
      this.hideTyping();
      const reply = this.generateReply(text);
      this.addMessage('ai', reply);
      this.speak(reply);
      if (this.autoListen) {
        setTimeout(() => this.startMic(), 800);
      }
    }, 600 + Math.random() * 800);
  },

  addMessage(role, text) {
    const container = this.$('#chat-messages');
    const div = document.createElement('div');
    div.className = `message ${role}`;

    const avatar = role === 'ai'
      ? `<div class="avatar om-avatar">ॐ</div>`
      : `<div class="avatar">U</div>`;

    // Simple markdown-ish
    let html = this.formatText(text);

    div.innerHTML = `${avatar}<div class="bubble">${html}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;

    // Update recent
    this.addRecent(role === 'user' ? text : 'SHIV replied');
  },

  formatText(text) {
    // Escape HTML
    let t = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Code blocks
    t = t.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    // Inline code
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    // Bold
    t = t.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    // Newlines
    t = t.replace(/\n/g, '<br>');
    return t;
  },

  showTyping() {
    const container = this.$('#chat-messages');
    const div = document.createElement('div');
    div.className = 'message ai typing';
    div.id = 'typing-indicator';
    div.innerHTML = `
      <div class="avatar om-avatar">ॐ</div>
      <div class="bubble">
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
      </div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  },

  hideTyping() {
    this.$('#typing-indicator')?.remove();
  },

  // ========== Smart Local Replies (Demo AI) ==========
  generateReply(userText) {
    const t = userText.toLowerCase();

    // Greetings
    if (/namaste|hello|hi |hey|namaskar|pranam/.test(t)) {
      return this.pick([
        '🙏 Namaste! Main SHIV AI hoon. Aap Hindi, English ya Hinglish mein baat kar sakte ho. Kya help chahiye?',
        '🙏 Pranam! SHIV AI ready hai. Bolkar ya type karke command do — Business, Code, Creative, kuch bhi!',
        'Hey! ॐ SHIV AI yahan hai. Voice se bhi baat kar sakte ho. Bataiye kya chahiye?'
      ]);
    }

    // LADLA RENT
    if (/ladla.?rent|rent kholo|rent business/.test(t)) {
      return `🏠 **LADLA RENT** mode activated!\n\nMain aapko help kar sakta hoon:\n• Best pricing strategy\n• Marketing plan (local + online)\n• Customer acquisition tips\n• Festival offers ideas\n• Profit margin improve karne ke tareeke\n\nBataiye specifically kya chahiye? Jaise “pricing strategy batao” ya “marketing plan do”.`;
    }

    // Business ideas
    if (/business idea|naye business|business ideas/.test(t)) {
      return `💡 **5 Business Ideas for LADLA GROUP / Rent space:**\n\n1. **Smart Storage Lockers** — Small size lockers for students & travelers (monthly rent).\n2. **Event Equipment Rental** — Speakers, lights, mandap items for functions.\n3. **Work-from-home Desk Rental** — Daily/weekly desk + wifi packages.\n4. **Festival Decoration Kits** — Diwali, Holi, wedding decoration packages on rent.\n5. **Vehicle + Driver Combo** — Car/bike with driver for local trips (subscription model).\n\nKaunsa idea deepen karna hai?`;
    }

    // Pricing
    if (/pricing|price strategy|rate/.test(t)) {
      return `💰 **Pricing Strategy Tips (Rent Business):**\n\n• **Tiered Pricing**: Basic / Standard / Premium packages banao.\n• **Dynamic Pricing**: Peak season (festivals, exams) mein 15-25% zyada.\n• **Loyalty Discount**: 3+ months ke customers ko 10% off.\n• **Bundle Offers**: 2 items saath rent pe extra discount.\n• **Local Competitor Check**: Har 2 mahine competitor rates check karo.\n\nExample: Single room ₹X, with AC + WiFi ₹X+Y. Clear value dikhao.`;
    }

    // Marketing
    if (/marketing|promotion|advertise/.test(t)) {
      return `📢 **Marketing Plan — LADLA RENT style:**\n\n1. **WhatsApp Status + Groups** — Daily before-after photos, offers.\n2. **Instagram Reels** — “Room ready in 10 min” type quick videos.\n3. **Google Business Profile** — Reviews collect karo, photos update rakho.\n4. **Referral Bonus** — “Dost ko bhejo, dono ko 1 din free”.\n5. **Festival Campaigns** — Diwali special, New Year packages.\n6. **Local Flyers + QR** — Nearby colleges, offices mein distribute.\n\nKaunsa channel pe focus karna hai pehle?`;
    }

    // Poster / Creative
    if (/poster|banner|reel|tagline|creative|design/.test(t)) {
      return `🎨 **Creative Concept:**\n\n**Poster Idea — LADLA RENT**\n• Headline: “Ghar jaisa comfort, Rent pe!”\n• Sub: “AC • WiFi • Clean • Affordable”\n• Visual: Clean room photo + warm lighting + QR code\n• CTA: “Aaj hi book karo — WhatsApp pe”\n• Colors: Deep blue + gold accent (trust + premium feel)\n\n**Reel Script (15 sec):**\n0-3s: Dirty/empty room flash\n3-8s: Fast clean + set up\n8-12s: Happy customer walking in\n12-15s: Logo + “LADLA RENT — Call Now”\n\nAur detailed version chahiye to batao!`;
    }

    // Code / Developer
    if (/code|html|css|javascript|js |pwa|navbar|developer/.test(t)) {
      return `🛠️ **Developer Mode**\n\nMain HTML/CSS/JS code generate aur explain kar sakta hoon.\n\nExample — Simple responsive button:\n\`\`\`html\n<button class="btn">Click Me</button>\n\`\`\`\n\`\`\`css\n.btn {\n  padding: 12px 24px;\n  background: #6366f1;\n  color: white;\n  border: none;\n  border-radius: 8px;\n  font-size: 1rem;\n  cursor: pointer;\n}\n.btn:hover { background: #818cf8; }\n\`\`\`\n\nKya specific code chahiye? Navbar, form, PWA, dark mode, kuch bhi bolo.`;
    }

    // File related
    if (/file|document|pdf|summary|upload/.test(t)) {
      return `📂 **File Assistant**\n\nAbhi demo mode mein hai. File upload karke aap:\n• Text files ka summary le sakte ho\n• Questions poochh sakte ho content pe\n\nFile Assistant section mein jaake koi .txt file upload karke try karo. Future mein PDF/DOC support bhi aa sakta hai.`;
    }

    // Voice / settings
    if (/voice|awaaz|bolkar|mic/.test(t)) {
      return `🎤 **Voice Features**\n\n• Mic button dabao → bolo → text aa jaayega\n• 🔊 button se Voice Reply ON/OFF kar sakte ho\n• Settings mein language (Hindi / English / Hinglish) change karo\n• Auto-listen bhi on kar sakte ho (reply ke baad phir se sunega)\n\nChrome ya Edge mein best kaam karta hai.`;
    }

    // Help / features
    if (/help|kya kar|features|kya hai|menu/.test(t)) {
      return `⚡ **SHIV AI Features:**\n\n💬 Smart Chat — Hindi + English + Hinglish\n🎤 Voice Input — bolkar command do\n🔊 Voice Reply — SHIV AI awaaz mein jawab\n💼 Business Mode — LADLA GROUP ideas, pricing, marketing\n🛠️ Developer Mode — HTML/CSS/JS code\n🎨 Creative Mode — poster, reel, tagline concepts\n📂 File Assistant — documents samajhna\n📊 Dashboard — activity track\n🔐 Settings & Privacy — local data\n📱 PWA — phone pe install kar sakte ho\n\nQuick Actions bhi try karo neeche!`;
    }

    // Default intelligent fallback
    const defaults = [
      `Samajh gaya: “${userText}”\n\nMain ispe detail se help kar sakta hoon. Thoda aur specific batao — Business side, Code side, ya Creative side?`,
      `Accha question! 🙏\n\nIs topic pe main tips, steps, examples de sakta hoon. Aapko list chahiye, plan chahiye, ya code chahiye?`,
      `SHIV AI soch raha hai…\n\nAapne kaha: “${userText.slice(0, 60)}${userText.length > 60 ? '…' : ''}”\n\nBusiness Mode, Developer Mode ya Creative Mode mein se koi choose karo, ya seedha sawaal poochho!`
    ];
    return this.pick(defaults);
  },

  pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  },

  // ========== File ==========
  handleFile(file) {
    const info = this.$('#file-info');
    info.classList.remove('hidden');
    info.innerHTML = `<strong>${file.name}</strong><br><small>${(file.size / 1024).toFixed(1)} KB • ${file.type || 'unknown'}</small>`;

    if (file.type.startsWith('text/') || file.name.endsWith('.txt') || file.name.endsWith('.json') || file.name.endsWith('.csv')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target.result.slice(0, 1500);
        this.switchView('chat');
        this.addMessage('user', `📄 File: ${file.name}`);
        this.showTyping();
        setTimeout(() => {
          this.hideTyping();
          const summary = `📂 **File Summary (first part):**\n\n${content.slice(0, 400)}${content.length > 400 ? '…' : ''}\n\nFile mil gaya! Ispe kya poochhna hai? Summary, key points, ya koi specific question?`;
          this.addMessage('ai', summary);
          this.speak('File mil gaya. Ispe kya poochhna hai?');
        }, 700);
      };
      reader.readAsText(file);
    } else {
      this.switchView('chat');
      this.addMessage('ai', `📄 “${file.name}” upload hua.\n\nAbhi demo mein mainly text files support hain. PDF/DOC ke liye future update aayega. Text file try karo ya content paste karke poochho.`);
    }
  },

  // ========== Stats ==========
  updateStats() {
    this.$('#stat-chats').textContent = this.chatCount;
    this.$('#stat-messages').textContent = this.msgCount;
    this.$('#stat-voice').textContent = this.voiceCount;
  },

  addRecent(text) {
    const list = this.$('#recent-list');
    if (!list) return;
    const li = document.createElement('li');
    const time = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    li.textContent = `${time} — ${text.slice(0, 50)}${text.length > 50 ? '…' : ''}`;
    if (list.children[0]?.textContent.includes('No recent')) list.innerHTML = '';
    list.prepend(li);
    if (list.children.length > 8) list.lastChild.remove();
  }
};

// Boot
document.addEventListener('DOMContentLoaded', () => {
  SHIV.init();
  // Register Service Worker for PWA
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  }
});

// PWA install prompt helper
let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
});
